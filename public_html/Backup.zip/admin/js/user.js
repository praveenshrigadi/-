$( document ).ready( function ()
{
var url = baseurl;


function UserList() {
    $.ajax({
        url: url + 'admin/script/UserList.php',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            // Initialize DataTable
            var reportTable = $('#User_List').DataTable({
                destroy: true,
                data: data,
                columns: [
                    { 
					"data": "id"
					},
					 { 
					"data": "name"
					},
					 { 
					"data": "phone_number"
					},
				  {
                        "data": "email"
                    }, {
                        "data": "status",
						"render": function (data, type, full, meta) {
                           return data === '1' ? '<span class="badge bg-success">Active</span>' :
                                                     '<span class="badge bg-danger">Inactive</span>';
                        }
                    },
					 { 
					"data": "id",
					"render": function (data, type, full, meta) {
                            return '<i data-id=' + data + ' id="delete" class="fa fa-trash text-danger" style="cursor:pointer" title="Delete"></i>';
                        }
					},
                    
                ]
            });
        },
        error: function (error) {
            console.error('Error fetching data:', error);
        }
    });
}


$(document).on('click', '#delete', function(){
		var id = $(this).attr("data-id");

		if(confirm("Are you sure you want to remove this?"))
		{
			$.ajax({
				url:url + "/admin/script/delete_user.php",
				method:"POST",
				data:{id:id},
				success:function(data){
			var obj = jQuery.parseJSON(data);
                    
                    if(obj.error == 'success'){
                       toastr.success(obj.msg);
                        UserList();
                    }else{
         toastr.error(obj.msg); 
                    }}
			});
		}
	});
	
	UserList();
});