<!-- /.login-box -->
<div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
<!-- Toastr -->
<script src="<?= BaseUrl; ?>admin/plugins/toastr/toastr.min.js"></script>
<!-- Summernote -->
<script src="<?= BaseUrl; ?>admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- Select2 -->
<script src="<?= BaseUrl; ?>admin/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= BaseUrl; ?>admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= BaseUrl; ?>admin/plugins/jquery-validation/jquery.validate.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?= BaseUrl; ?>admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= BaseUrl; ?>admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= BaseUrl; ?>admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= BaseUrl; ?>admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?= BaseUrl; ?>admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= BaseUrl; ?>admin/dist/js/adminlte.min.js"></script>
<!-- Toastr -->
<script src="<?= BaseUrl; ?>admin/plugins/toastr/toastr.min.js"></script>
<script>
var baseurl = '<?= BaseUrl; ?>';
</script>