 <!-- Main Footer -->
 <footer class="main-footer">
     <strong>Copyright &copy; 2022 - <?= date("Y"); ?> <a href="<?= website; ?>"><?= AppName?></a>.</strong>
     All rights reserved.
 </footer>