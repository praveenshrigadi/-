  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
    <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/summernote/summernote-bs4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/toastr/toastr.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  
  <!-- Font Awesome -->

  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/plugins/fontawesome-free/css/all.min.css">
  
  <link rel="stylesheet" href="<?= BaseUrl; ?>assets/css/flaticon.css">
  <link rel="stylesheet" href="<?= BaseUrl; ?>assets/css/linearicons.css">



<!-- jQuery -->
<script src="<?= BaseUrl; ?>admin/plugins/jquery/jquery.min.js"></script>
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= BaseUrl; ?>admin/dist/css/adminlte.min.css">